﻿namespace WizardFramework
{
    /// <summary>
    /// Represents that the implemented classes are data models for wizard page.
    /// </summary>
    public interface IWizardModel
    {
    }
}