﻿using WizardFramework;

namespace InstallerSample
{
    public partial class FrmInstaller : Wizard
    {
        public FrmInstaller()
        {
            InitializeComponent();
        }
    }
}