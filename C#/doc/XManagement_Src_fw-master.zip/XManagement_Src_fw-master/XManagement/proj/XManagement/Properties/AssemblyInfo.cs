﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("XManagement")]
[assembly: AssemblyDescription("X Management System")]

// 如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
[assembly: Guid("cbdbc1e8-4384-45b6-b10a-e8c116822d20")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]