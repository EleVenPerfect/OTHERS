﻿namespace BobWei.XManagement.UI
{
    public partial class DummyFunctionTreeWindow : ToolWindow
    {
        public DummyFunctionTreeWindow()
        {
            InitializeComponent();
        }
    }
}
