﻿namespace BobWei.XManagement.UI
{
    public partial class DummyReportDoc : DocumentWindow
    {
        public DummyReportDoc()
        {
            InitializeComponent();
        }
    }
}
