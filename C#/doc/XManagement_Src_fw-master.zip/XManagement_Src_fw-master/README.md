# XManagement_Src_fw

<img src="2016-11-02_145426.png" width="430" />

* You can upgrade sln to .NET Framework 4.5.2 by VS2015.
* Chinese help to read [doc/first.txt](./XManagement/doc/first.txt)
* Thanks DockPanel, ICSharpCode.SharpZLib and 7-zip projects develoeprs.
