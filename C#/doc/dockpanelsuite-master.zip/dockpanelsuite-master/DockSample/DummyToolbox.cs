namespace DockSample
{
    public partial class DummyToolbox : ToolWindow
    {
        public DummyToolbox()
        {
            InitializeComponent();
        }
    }
}