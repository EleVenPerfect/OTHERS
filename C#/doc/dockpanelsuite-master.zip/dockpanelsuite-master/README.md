DockPanel Suite
===============

[![Join the chat at https://gitter.im/dockpanelsuite/dockpanelsuite](https://img.shields.io/gitter/room/dockpanelsuite/dockpanelsuite.svg?style=flat-square)](https://gitter.im/dockpanelsuite/dockpanelsuite?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![NuGet Version](https://img.shields.io/nuget/v/DockPanelSuite.svg?style=flat-square)](https://www.nuget.org/packages/DockPanelSuite/)
[![Build status](https://img.shields.io/appveyor/ci/lextm/dockpanelsuite/master.svg?label=appvejor&style=flat-square)](https://ci.appveyor.com/project/lextm/dockpanelsuite)
[![Stories in Progress](https://img.shields.io/waffle/label/dockpanelsuite/dockpanelsuite/in%20progress.svg?style=flat-square)](http://waffle.io/dockpanelsuite/dockpanelsuite) 

[![Throughput Graph](https://graphs.waffle.io/dockpanelsuite/dockpanelsuite/throughput.svg?style=flat-square)](https://waffle.io/dockpanelsuite/dockpanelsuite/metrics/throughput) 

DockPanel Suite - The Visual Studio inspired docking library for .NET WinForms

For more details, check out [http://dockpanelsuite.com](http://dockpanelsuite.com).

Visual Studio 2015 Community edition and above is recommended to compile the code base.
