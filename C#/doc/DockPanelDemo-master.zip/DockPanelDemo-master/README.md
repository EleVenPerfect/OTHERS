# DockPanelDemo
Demo for DockPanel,DockPanel实例
具体请见我的博客：http://www.guoxiaozhong.cn/2016/11/04/c-xia-de-dockpanelsuiteyong-fa/
