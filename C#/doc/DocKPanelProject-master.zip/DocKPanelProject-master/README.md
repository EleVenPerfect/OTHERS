DocKPanelProject
================

应用DockPanel编写的CSharp软件，最终实现拖拽控件配置属性功能
